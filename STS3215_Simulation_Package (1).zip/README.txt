STS3215 offline visual preview for original 20 motion files.
C1R1 top-left, C3R3 bottom-right. Recorded only C1R1/C2R1; other cells estimated.
Gestures are relative servo offsets shown about an INVENTED standby for visualization only.
The model dimensions, joint offsets, collisions and standby are NOT verified. Do not execute poses from this animation on hardware.
