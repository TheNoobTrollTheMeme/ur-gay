from pathlib import Path
import json, math, subprocess, time
from PIL import Image, ImageDraw, ImageFont
import numpy as np

ROOT=Path('/mnt/data/STS3215_Motions_Only')
OUT=Path('/mnt/data/STS3215_Simulation')
OUT.mkdir(exist_ok=True)
SIZE=(960,540)
FPS=20
RAD=2*math.pi/4096
OFF=[3,55,-50,-5]
DIR=[-1,1,1,1]
L=[140,125,80]
H=170
FONT='/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf'
BOLD='/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf'
FB=ImageFont.truetype(BOLD,32)
FT=ImageFont.truetype(BOLD,18)
FM=ImageFont.truetype(FONT,17)
FS=ImageFont.truetype(FONT,13)
FSEC=ImageFont.truetype(BOLD,12)
WHITE='#EDF6FF'; SUB='#A5B5CC'; CYAN='#4DE4E5'; GOLD='#FFBB63'; BG='#091426'; RED='#FF827D'
# Load EXACT saved tick values (not invented, except nonphysical illustrative gesture standby)
grid={}
for row in range(1,4):
 for col in range(1,4):
  k=f'c{col}r{row}'
  grid[k]={}
  for stage in 'mp':
   d=json.loads((ROOT/'grid'/f'{k}{stage}.json').read_text())
   grid[k][stage]=[[float(t) for t in p['input_values']] for p in d['points']]
relative={name:json.loads((ROOT/'gestures'/f'{name}.relative.json').read_text()) for name in ['attack_signal','victory_pump']}
# Chosen ONLY so motion is visible in a virtual scene; NOT safe, calibrated or executable standby pose.
PREVIEW_STANDBY=[2090,2597,1719,1524,2400]

# True from model assumption file, not measured dimensions.
def chain(raw):
 b,s,e,w=[(raw[i]-2048)*RAD*DIR[i]+math.radians(OFF[i]) for i in range(4)]
 rs=[0,L[0]*math.cos(s),L[0]*math.cos(s)+L[1]*math.cos(s+e),L[0]*math.cos(s)+L[1]*math.cos(s+e)+L[2]*math.cos(s+e+w)]
 zs=[H,H+L[0]*math.sin(s),H+L[0]*math.sin(s)+L[1]*math.sin(s+e),H+L[0]*math.sin(s)+L[1]*math.sin(s+e)+L[2]*math.sin(s+e+w)]
 return [(r*math.sin(b),r*math.cos(b),z) for r,z in zip(rs,zs)]

def point(x,y,z):
 # arm-side view: X increases right, Z increases up; slight pseudo-perspective shift with Y
 return (round(600+1.45*x+0.65*(y-301)),round(515-1.18*z+0.10*(y-301)))

def tween(a,b,t):return [x*(1-t)+y*t for x,y in zip(a,b)]

def rounded(draw,xy,fill,outline=None,width=1,r=12):
 draw.rounded_rectangle(xy,fill=fill,outline=outline,width=width,radius=r)

# Scene duration 1.56 sec per grid; 1.5 attack; 2.8 victory
scenes=[]
for r in range(1,4):
 for c in range(1,4):
  k=f'c{c}r{r}'
  scenes.append({'id':k,'duration':1.56,'title':k.upper(),'kind':'grid','col':c,'row':r})
scenes += [{'id':'attack_signal','duration':1.75,'title':'ATTACK SIGNAL','kind':'gesture'}, {'id':'victory_pump','duration':3.2,'title':'VICTORY DANCE','kind':'gesture'}]
total=sum(s['duration'] for s in scenes)

# Interpolate *within* recorded move/place segments; no manufactured transitions between cells.
def pose_for(sc,t):
 if sc['kind']=='grid':
  m,p=grid[sc['id']]['m'],grid[sc['id']]['p']
  q=t/sc['duration']
  if q<.48:
   z=min(1,q/.48)
   return tween(m[0],m[1],z), 'MOVE  •  clearance to cell'
  if q<.57:
   z=(q-.48)/.09
   return tween(m[1],p[0],z),'RELEASE  •  interpolated transition'
  z=min(1,(q-.57)/.43)
  return tween(p[0],p[1],z),'PLACE  •  recorded / estimated path'
 info=relative[sc['id']]['stages']
 stages=[([PREVIEW_STANDBY[i]+float(d) for i,d in enumerate(step['relative_tick_offsets'])],max(50,step.get('suggested_dwell_ms',150))) for step in info]
 # Time-stretch all suggested stage durations so it is obvious on screen
 intervals=[x[1] for x in stages]
 u=min(.9999,t/sc['duration'])*sum(intervals)
 accum=0
 for i,dur in enumerate(intervals):
  if u<=accum+dur:
   frac=(u-accum)/dur
   if i==0:return stages[0][0],info[0]['label']
   # Whole fraction interpolates from preceding stage
   return tween(stages[i-1][0],stages[i][0],frac),info[i]['label'].replace('_',' ').upper()
  accum+=dur
 return stages[-1][0],info[-1]['label']

def create_frame(sc,sc_t,global_t):
 img=Image.new('RGB',SIZE,BG);d=ImageDraw.Draw(img)
 # Subtle blueprint grid
 for x in range(12,950,42):d.line((x,0,x,540),fill='#0C2034',width=1)
 for y in range(12,540,42):d.line((0,y,960,y),fill='#0C2034',width=1)
 d.text((28,23),'STS3215  ·  5-DOF MOTION PREVIEW',font=FT,fill=WHITE)
 d.text((28,52),'SIMULATED JOINT PATHS  /  NOT PHYSICALLY VALIDATED',font=FS,fill=GOLD)
 # grid frame behind arm, plausible visual placement only
 xcols=[-65.9,33.7,133.3]
 zrows=[263,163.4,63.8]
 step=99.6;y=301
 # colored cell panels
 for r in range(3):
  for c in range(3):
   x=xcols[c]; z=zrows[r]
   px,py=point(x,y,z)
   if sc['kind']=='grid' and sc['col']==c+1 and sc['row']==r+1:
    rounded(d,(px-65,py-49,px+65,py+49),fill='#154854',outline=CYAN,width=2,r=7)
   else:
    rounded(d,(px-64,py-48,px+64,py+48),fill='#10263A',outline='#274154',width=1,r=7)
   d.text((px-20,py-9),f'{c+1},{r+1}',font=FM,fill=CYAN if sc['kind']=='grid' and sc['col']==c+1 and sc['row']==r+1 else '#8195AD')
 # bar dividers rack
 for c in [-0.5,.5,1.5,2.5]:
  x=xcols[0]+c*step
  a=point(x,y,zrows[0]+step/2);b=point(x,y,zrows[-1]-step/2)
  d.line([a,b],fill='#61788A',width=9 if c in (-.5,2.5) else 7)
  d.line([a,b],fill='#B7C2CD',width=2)
 for r in [-.5,.5,1.5,2.5]:
  z=zrows[0]-r*step
  a=point(xcols[0]-step/2,y,z);b=point(xcols[-1]+step/2,y,z)
  d.line([a,b],fill='#61788A',width=9 if r in (-.5,2.5) else 7)
  d.line([a,b],fill='#B7C2CD',width=2)
 raw,label=pose_for(sc,sc_t)
 pts=[point(*q) for q in chain(raw)]
 # ghost floor base stem / arm
 bx,by=pts[0]
 d.ellipse((bx-41,by-20,bx+41,by+20),fill='#1D354D',outline='#7194B2',width=4)
 d.ellipse((bx-26,by-13,bx+26,by+13),fill='#344D6C',outline='#A8BED0',width=2)
 d.line(pts[:2],fill='#1B3548',width=26)
 d.line(pts[:2],fill=CYAN,width=15)
 d.line(pts[1:3],fill='#1B3548',width=23)
 d.line(pts[1:3],fill=CYAN,width=12)
 d.line(pts[2:4],fill='#5B382D',width=20)
 d.line(pts[2:4],fill=GOLD,width=11)
 for i,p in enumerate(pts[:-1]):
  rad=14 if i else 17
  d.ellipse((p[0]-rad,p[1]-rad,p[0]+rad,p[1]+rad),fill='#17263C',outline='#D6E7F5',width=4)
 # wrist gripper silhouette
 ex,ey=pts[-1]
 d.ellipse((ex-9,ey-9,ex+9,ey+9),fill='#F3C98A',outline='#FFF0C2',width=2)
 d.line((ex-8,ey-7,ex-14,ey-19),fill='#FFE2B4',width=4)
 d.line((ex+8,ey+7,ex+14,ey+19),fill='#FFE2B4',width=4)
 # text card
 rounded(d,(25,115,284,330),'#0F2339',outline='#284A68',width=2)
 d.text((42,136),sc['title'],font=FB,fill=CYAN if sc['kind']=='grid' else GOLD)
 if sc['kind']=='grid':
  provenance='RECORDED SOURCE' if sc['id'] in ('c1r1','c2r1') else 'ESTIMATED / UNTESTED'
  if sc['id']=='c3r3':provenance='C3R3: REACH UNCERTAIN'
  d.text((43,179),provenance,font=FS,fill='#7BE6B4' if sc['id'] in ('c1r1','c2r1') else RED)
 else:
  d.text((42,179),'RELATIVE OFFSETS ONLY',font=FS,fill=RED)
  d.text((42,205),'Virtual standby shown',font=FS,fill=SUB)
 d.text((42,247),label[:29],font=FS,fill=WHITE)
 d.text((42,285),f'Wrist: {round(raw[3])} ticks',font=FS,fill=SUB)
 # timeline
 d.line((30,493,930,493),fill='#3D566F',width=5)
 progress=min(1,max(0,global_t/total));d.line((30,493,30+900*progress,493),fill=CYAN,width=5)
 d.text((30,506),f'{global_t:05.1f} s / {total:.1f} s',font=FSEC,fill=SUB)
 d.text((580,506),'C1 LEFT   •   R1 TOP',font=FSEC,fill=SUB)
 if sc['id']=='c3r3':d.text((35,352),'C3R3 MAY BE UNREACHABLE',font=FS,fill=RED)
 return img

# Render 20fps for compatibility
proc=subprocess.Popen(['ffmpeg','-y','-hide_banner','-loglevel','error','-f','rawvideo','-pix_fmt','rgb24','-s','%dx%d'%SIZE,'-r',str(FPS),'-i','-','-c:v','libx264','-preset','ultrafast','-crf','22','-pix_fmt','yuv420p','-movflags','+faststart',str(OUT/'all_motions_simulation.mp4')],stdin=subprocess.PIPE)
frame_n=0; begin=0
for sc in scenes:
 n=max(1,round(sc['duration']*FPS))
 for i in range(n):
  t=(i+0.25)/FPS
  image=create_frame(sc,min(sc['duration'],t),begin+t)
  if sc['id']=='c1r1' and i==n//2:image.save(OUT/'preview.png')
  if sc['id']=='c3r3' and i==n//2:image.save(OUT/'c3r3_preview.png')
  if sc['id']=='victory_pump' and i==n//2:image.save(OUT/'victory_preview.png')
  proc.stdin.write(image.tobytes());frame_n+=1
 begin+=sc['duration']
proc.stdin.close();code=proc.wait()
if code:raise RuntimeError('ffmpeg failed')
# a GIF of ~6 seconds sampling selected illustrative sequences, fps 9
proc=subprocess.run(['ffmpeg','-y','-hide_banner','-loglevel','error','-i',str(OUT/'all_motions_simulation.mp4'),'-vf',"fps=6,scale=640:-1:flags=lanczos",'-loop','0',str(OUT/'all_motions_simulation.gif')],capture_output=True,text=True)
print('gif',proc.returncode,proc.stderr[:200])
# Save source data / preview assumptions for reproducibility
meta={'source':'STS3215_Motions_Only','grid':grid,'relative_gestures':relative,'preview_standby_raw':PREVIEW_STANDBY,
'preview_standby_is_measured':False,'model_assumptions':json.loads((Path('/mnt/data/robot-grid-planner/simulation_only/model_assumptions.json')).read_text()),'warning':'Illustrative model: no measured 5DOF CAD, joint limits, collision meshes, or verified standby. Do not use video to validate hardware.'}
(OUT/'simulation_data.json').write_text(json.dumps(meta,indent=2))
(OUT/'README.txt').write_text('STS3215 offline visual preview for original 20 motion files.\nC1R1 top-left, C3R3 bottom-right. Recorded only C1R1/C2R1; other cells estimated.\nGestures are relative servo offsets shown about an INVENTED standby for visualization only.\nThe model dimensions, joint offsets, collisions and standby are NOT verified. Do not execute poses from this animation on hardware.\n')
print('frames:',frame_n,'length seconds',total)
for p in OUT.iterdir():print(p.name,p.stat().st_size)
