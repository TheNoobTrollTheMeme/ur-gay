# STS3215 5DOF: grid placements + two gestures (MOTIONS ONLY)

**Grid orientation from the ARM side**

| | Column 1 (left) | Column 2 | Column 3 (right) |
|---|---|---|---|
| Top row 1 | C1R1 | C2R1 | C3R1 |
| Middle row 2 | C1R2 | C2R2 | C3R2 |
| Bottom row 3 | C1R3 | C2R3 | C3R3 |

## Contents

- `grid/`: **18 normal raw encoder JSON files**: `c1r1m.json` and `c1r1p.json` through `c3r3m.json` and `c3r3p.json`. These preserve your earlier exported servo targets and clearance waypoints unchanged.
- `gestures/attack_signal.relative.json`: **two wrist nods**, `+12 ticks -> 0`, twice; all other joints fixed.
- `gestures/victory_pump.relative.json`: **four rhythmic elbow/wrist pump cycles**, returning to the standby pose; base and gripper stay fixed. This is the requested cheeky victory dance, not an attack.
- `standby_TEMPLATE.json`: required measured safe pose, which is **not available while the robot is inaccessible**.
- `build_absolute_gestures.py`: converts relative gesture JSONs into the same `pose_sequence` / `raw` format as your grid JSONs **once a safe standby pose and full swept volume have actually been tested**.
- `STATUS.json`: provenance and live-use status.

## Provenance and limitations

**Recorded from original source:** `c1r1m/p`, `c2r1m/p` (4 files). These still need clearance checks on your actual robot.
**Estimated:** all other grid JSONs (14 files). These have NOT been physically validated. The previous approximate kinematic model could not reach **C3R3** under its *assumed* geometry, so C3R3 is particularly uncertain. The 18 grid JSONs use valid 0..4095 STS3215 encoder values, but valid numbers do **not** prove reachability or collision freedom.

The physical standby for gestures is unknown. **Do not substitute any grid-entry pose.** The gesture plans contain **relative** tick offsets, intentionally not guessed absolute positions. The existing Pi runner's `pose_sequence` loader will not run these relative JSON templates directly.

## Later, when you have the hardware

1. Capture five raw encoder ticks at a safe standby pose, with the robot and its planned swept volume fully outside the rack, restricted playing zone, people and cables. Ensure the gripper is empty.
2. At low speed, test each pulse, its return to standby and the *whole* path with a supervisor/emergency stop. Verify the rack and zone do not get approached.
3. Fill a **copy** of `standby_TEMPLATE.json` with the measured `standby_raw` array and set the three verification fields true **only after physical testing**.
4. Convert the gesture plans:

```bash
python3 build_absolute_gestures.py --standby-file my_measured_standby.json --out generated_gestures
```

The outputs are `generated_gestures/attack_signal.json` and `generated_gestures/victory_pump.json`, both ordinary five-servo raw `pose_sequence` files. To execute with your existing Pi runner, its motion lookup directory and `calibration_status.json` must be updated; **it will block live execution until individually validated.** The runner does not implement the suggested timing/dwell fields in relative templates. Start at low speed after the paths are measured.

**Attack signal is a notification only.** You still must verbally announce the attack and receive referee approval before any authorized rack entry. Do not dance or twitch during actual block placement, while holding a block, or before the contest start signal. Use the victory sequence only after the round has ended, when event personnel allow it. Keep gestures small and controlled, not violent shaking.

### On Windows: copy files to the Pi (both devices on the same network)

From the parent folder holding this directory:

```powershell
scp -r .\STS3215_Motions_Only YOUR_PI_USERNAME@PI_IP:~/
```

The 18 grid JSON files are already usable *as input data* with your existing Pi runner, after being copied into that runner's `motions/` directory, subject to physical verification. **Do not run unknown poses at competition speed.**
