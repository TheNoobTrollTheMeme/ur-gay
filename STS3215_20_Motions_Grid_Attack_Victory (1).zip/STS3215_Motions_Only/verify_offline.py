#!/usr/bin/env python3
from pathlib import Path
import json
from build_absolute_gestures import compile_gesture
ROOT=Path(__file__).resolve().parent
files=list((ROOT/'grid').glob('*.json'))
assert len(files)==18,len(files)
expected={f'c{c}r{r}{t}' for r in (1,2,3) for c in (1,2,3) for t in 'mp'}
assert {p.stem for p in files}==expected
for p in files:
 d=json.loads(p.read_text())
 assert d['type']=='pose_sequence' and d['input_type']=='raw' and d['name']==p.stem
 assert len(d['points'])==2 and all(len(x['input_values'])==5 for x in d['points'])
 assert all(0<=int(v)<=4095 for x in d['points'] for v in x['input_values'])
for name in ('attack_signal','victory_pump'):
 d=json.loads((ROOT/'gestures'/f'{name}.relative.json').read_text())
 assert d['stages'][0]['relative_tick_offsets']==d['stages'][-1]['relative_tick_offsets']==[0]*5
 assert all(s['relative_tick_offsets'][0]==s['relative_tick_offsets'][4]==0 for s in d['stages'])
 fake={'standby_raw':[2048]*5,'standby_clearance_physically_verified':True,'empty_gripper_verified':True,'gesture_sweep_physically_verified':True}
 out=compile_gesture(d,fake)
 assert out['name']==name
 assert all(0<=int(v)<=4095 for p in out['points'] for v in p['input_values'])
 try:
  fake['gesture_sweep_physically_verified']=False
  compile_gesture(d,fake)
  raise AssertionError('Unverified gesture compiled!')
 except ValueError: pass
print('PASS: 18 grid files and both relative gestures, format, bounds, and safety gate')
