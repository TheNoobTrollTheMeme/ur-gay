#!/usr/bin/env python3
"""Convert relative gesture plans to the existing STS3215 raw pose_sequence format.

Only accepts a physically measured, clear standby pose, plus affirmative flags.
Outputs are still not automatically approved for live execution by any runner.
"""
from pathlib import Path
import argparse, json

ROOT=Path(__file__).resolve().parent

def compile_gesture(gesture, standby):
    if gesture['type'] != 'relative_joint_sequence':
        raise ValueError('expected relative_joint_sequence')
    if any(standby[k] is not True for k in ('standby_clearance_physically_verified','empty_gripper_verified','gesture_sweep_physically_verified')):
        raise ValueError('Standby, empty gripper, and entire gesture swept volume must first be physically verified.')
    raw=standby.get('standby_raw')
    if not isinstance(raw,list) or len(raw)!=5 or any(type(n) is not int or not 0<=n<=4095 for n in raw):
        raise ValueError('standby_raw must be five measured integer encoder positions from 0 through 4095')
    stages=gesture['stages']
    if stages[0]['relative_tick_offsets']!=[0]*5 or stages[-1]['relative_tick_offsets']!=[0]*5:
        raise ValueError('gestures must start and finish at the baseline')
    points=[]
    for stage in stages:
        offsets=stage['relative_tick_offsets']
        if len(offsets)!=5 or any(type(x) is not int or abs(x)>60 for x in offsets):
            raise ValueError('relative offsets must be five integers and within 60 ticks')
        if offsets[4] != 0 or offsets[0] != 0:
            raise ValueError('gripper and base yaw must not change')
        vals=[int(v+o) for v,o in zip(raw,offsets)]
        if any(n<0 or n>4095 for n in vals):
            raise ValueError('gesture would exceed encoder range')
        points.append({'input_values':[str(v) for v in vals]})
    return {
        'schema_version':1,'type':'pose_sequence','name':gesture['name'],
        'description':gesture['description']+' GENERATED FROM PHYSICALLY VERIFIED STANDBY. REVALIDATE BEFORE LIVE RUN.',
        'input_type':'raw','joint_order':gesture['joint_order'],'points':points
    }

def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--standby-file',required=True,help='Copy standby_TEMPLATE.json; fill only measured values after on-device clearance checks')
    p.add_argument('--out',default='generated_gestures',help='Output directory; generated values still need live controller validation')
    args=p.parse_args()
    standby=json.loads(Path(args.standby_file).read_text())
    dest=Path(args.out); dest.mkdir(parents=True,exist_ok=True)
    for name in ('attack_signal','victory_pump'):
        d=json.loads((ROOT/'gestures'/f'{name}.relative.json').read_text())
        converted=compile_gesture(d,standby)
        out=dest/f'{name}.json'; out.write_text(json.dumps(converted,indent=2)+'\n')
        print('Wrote',out)
    print('These files are NOT enabled for live control. Individually verify them in your controller and keep an emergency stop available.')

if __name__=='__main__':main()
